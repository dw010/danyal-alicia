# Danyal & Alicia · 2PESQUET

Site statique prêt pour GitHub Pages.

## Publier

1. Décompressez cette archive et ajoutez ses fichiers à la racine d’un dépôt GitHub.
2. Dans **Settings → Pages**, choisissez **Deploy from a branch**, puis la branche principale et le dossier **/(root)**.

Ouvrez `index.html` pour voir le site localement. Aucun outil de compilation n’est nécessaire.
